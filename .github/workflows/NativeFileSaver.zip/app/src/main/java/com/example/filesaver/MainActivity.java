package com.example.filesaver;

import android.Manifest;
import android.os.Bundle;
import android.os.Environment;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    EditText filename, content;
    Button saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                1
        );

        filename = findViewById(R.id.filename);
        content  = findViewById(R.id.content);
        saveBtn  = findViewById(R.id.saveBtn);

        saveBtn.setOnClickListener(v -> saveFile());
    }

    private void saveFile() {
        try {
            String name = filename.getText().toString().trim();
            String text = content.getText().toString();

            if (name.isEmpty()) {
                Toast.makeText(this, "ফাইল নাম দিন!", Toast.LENGTH_SHORT).show();
                return;
            }

            File docDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOCUMENTS);

            if (!docDir.exists()) docDir.mkdirs();

            File file = new File(docDir, name);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(text.getBytes());
            fos.close();

            Toast.makeText(this,
                    "Saved in Documents 📂",
                    Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Toast.makeText(this,
                    "Error: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }
}
